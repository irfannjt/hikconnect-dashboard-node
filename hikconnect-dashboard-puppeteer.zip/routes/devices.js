const express = require('express');
const router = express.Router();
const db = require('../db');

router.get('/', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM devices ORDER BY id ASC');
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/update', async (req, res) => {
  try {
    const { id, status } = req.body;
    if (!id || !['Online','Offline'].includes(status)) return res.status(400).json({ success:false, error:'Invalid data' });
    await db.query('UPDATE devices SET status=? WHERE id=?', [status, id]);
    res.json({ success:true });
  } catch (err) {
    res.status(500).json({ success:false, error: err.message });
  }
});

module.exports = router;
