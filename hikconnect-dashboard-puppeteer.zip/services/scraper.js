const puppeteer = require('puppeteer');
const dotenv = require('dotenv');
dotenv.config();

async function scrapeHiConnect() {
  const user = process.env.HICONNECT_USER;
  const pass = process.env.HICONNECT_PASS;
  if (!user || !pass) {
    console.warn('HICONNECT_USER/HICONNECT_PASS not set - scraper will skip');
    return [];
  }

  const browser = await puppeteer.launch({
    headless: true,
    args: ['--no-sandbox','--disable-setuid-sandbox']
  });
  const page = await browser.newPage();
  try {
    // go to login page (may change); this POC attempts standard login flow
    await page.goto('https://www.hik-connect.com/views/main/index.html#/login', { waitUntil: 'networkidle2', timeout: 60000 });
    await page.waitForTimeout(1000);
    const userSel = 'input[type=email], input[name=username], input[placeholder*=Email], input[placeholder*=email]';
    const passSel = 'input[type=password], input[name=password]';
    await page.waitForSelector(userSel, { timeout: 5000 }).catch(()=>{});
    await page.type(userSel, user, { delay: 80 }).catch(()=>{});
    await page.type(passSel, pass, { delay: 80 }).catch(()=>{});
    await page.click('button[type=submit]').catch(()=>{});
    await page.waitForTimeout(5000);
    await page.goto('https://www.hik-connect.com/views/main/index.html#/common/personal/deviceManagement', { waitUntil:'networkidle2', timeout:60000 }).catch(()=>{});
    await page.waitForTimeout(3000);

    const devices = await page.evaluate(()=>{
      const list = [];
      const rows = document.querySelectorAll('.device-item, .device-row, .el-table__row');
      if (rows && rows.length){
        rows.forEach(r=>{
          const name = r.querySelector('.device-name, .el-table_ellipsis, .name')?.innerText?.trim() || r.querySelector('td')?.innerText?.trim();
          const statusText = r.querySelector('.device-status, .status, .el-tag')?.innerText?.trim() || '';
          list.push({ name, status: statusText });
        });
        return list;
      }
      const elements = Array.from(document.querySelectorAll('span,div')).filter(n=>/Online|Offline/i.test(n.innerText));
      const unique = [];
      elements.forEach(el=>{
        const txt = el.innerText.trim();
        if (!unique.includes(txt)) unique.push(txt);
      });
      return unique.map((s,i)=>({ name: 'device-'+i, status: s }));
    });
    await browser.close();
    return devices;
  } catch (err) {
    console.error('Scraper error', err.message);
    try{ await browser.close(); }catch(e){}
    return [];
  }
}

module.exports = { scrapeHiConnect };
